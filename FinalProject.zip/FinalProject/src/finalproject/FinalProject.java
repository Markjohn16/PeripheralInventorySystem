/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalproject;

/**
 *
 * @author ASUS
 */
public class FinalProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Loading ld = new Loading();
        ld.setVisible(true);
        
        MainFrame mf = new MainFrame();
        mf.setVisible(false);
        
        try{
                for (int i=0;i<=100;i++){
                    Thread.sleep(110);
                    ld.zero.setText(Integer.toString(i)+"%");
                    ld.runrabbit.setValue(i);
                    
                    if(i==100){
                        ld.dispose();
                    mf.show();
                    }
                    }
            }catch (Exception e){
            }    
        }
}
